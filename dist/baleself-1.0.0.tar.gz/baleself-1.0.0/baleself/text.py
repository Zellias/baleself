def link_text(text,url):
    return f"[{text}]({url})"